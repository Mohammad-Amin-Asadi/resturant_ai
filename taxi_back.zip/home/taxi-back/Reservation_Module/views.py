import base64
import json

from Crypto.Cipher import PKCS1_OAEP, AES
from django.urls import reverse_lazy
from django.views.generic import ListView, UpdateView
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from rest_framework.views import APIView
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import status
from Crypto.PublicKey import RSA

from Reservation_Module.models import ReservationModel, TelephoneTaxiModel, InscriptionModel
from Reservation_Module.forms import SettingsForm
from Reservation_Module.serializers import ReservationSerializer


class SettingView(UpdateView):
    template_name = 'Reservation_Module/settings_form_template.html'
    form_class = SettingsForm
    success_url = reverse_lazy('reservation_list_url')

    def get_context_data(self, **kwargs):
        context = super(SettingView, self).get_context_data(**kwargs)
        settings = TelephoneTaxiModel.objects.filter(is_active=True).first()
        context['settings'] = settings
        return context

    def get_object(self, queryset=None):
        return TelephoneTaxiModel.objects.filter(is_active=True).first()

    def form_valid(self, form):
        form.save()
        return super(SettingView, self).form_valid(form)


class ReservationListView(ListView):
    template_name = 'Reservation_Module/reservations_list_template.html'
    model = ReservationModel
    context_object_name = 'reservations'


class AddReservationView(APIView):
    def post(self, request: Request):
        public_key = request.data.get('public_key')
        data = request.data.get('data')
        if not public_key or not data:
            return Response('Public key and data are required', status=status.HTTP_400_BAD_REQUEST)

        inscription = InscriptionModel.objects.filter(public_key=public_key).first()
        if not inscription:
            return Response('Inscription does not exist', status=status.HTTP_400_BAD_REQUEST)

        try:
            data = self.decoder(inscription.private_key, data)
        except Exception as e:
            return Response(f'Decryption failed: {e}', status=status.HTTP_400_BAD_REQUEST)

        reservations = ReservationSerializer(data=data)
        if reservations.is_valid():
            reservations.save()
            return Response("OK", status=status.HTTP_201_CREATED)
        else:
            return Response(reservations.errors, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request: Request):
        inscription = InscriptionModel.objects.filter(use_count__lt=15).first()
        if inscription:
            public_key = inscription.public_key
            inscription.use_count += 1
            inscription.save()
            return Response({'public_key': public_key}, status=status.HTTP_200_OK)
        else:
            private_key, public_key = self.generate_keys()
            new_inscription = InscriptionModel(
                private_key=private_key,
                public_key=public_key,
                use_count=1
            )
            new_inscription.save()
            return Response({'public_key': public_key}, status=status.HTTP_200_OK)

    @staticmethod
    def decoder(private_key, data: str):
        """
        Hybrid decoder:
         - decode base64(JSON(package))
         - decrypt AES key with RSA private key
         - decrypt ciphertext with AES-GCM
        """
        # 1) decode wrapper base64 → JSON string
        package_json = base64.b64decode(data)
        package = json.loads(package_json)

        # 2) decode components
        enc_key = base64.b64decode(package['key'])
        nonce = base64.b64decode(package['nonce'])
        tag = base64.b64decode(package['tag'])
        ciphertext = base64.b64decode(package['ciphertext'])

        # 3) RSA decrypt the AES key
        private_key_obj = RSA.import_key(private_key)
        cipher_rsa = PKCS1_OAEP.new(private_key_obj)
        sym_key = cipher_rsa.decrypt(enc_key)

        # 4) AES-GCM decrypt
        cipher_aes = AES.new(sym_key, AES.MODE_GCM, nonce=nonce)
        plaintext = cipher_aes.decrypt_and_verify(ciphertext, tag)

        return json.loads(plaintext.decode("utf-8"))

    @staticmethod
    def generate_keys():
        key = RSA.generate(2048)
        private_key = key.export_key().decode("utf-8")
        public_key = key.publickey().export_key().decode("utf-8")
        return private_key, public_key


@method_decorator(csrf_exempt, name='dispatch')
class DeleteReservationView(APIView):
    def delete(self, request: Request, reservation_id: int):
        try:
            reservation = ReservationModel.objects.get(id=reservation_id)
            reservation.delete()
            return Response({'message': 'Reservation deleted successfully'}, status=status.HTTP_200_OK)
        except ReservationModel.DoesNotExist:
            return Response({'error': 'Reservation not found'}, status=status.HTTP_404_NOT_FOUND)