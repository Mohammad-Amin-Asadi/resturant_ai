from django.db import models


class ReservationModel(models.Model):
    user_fullname = models.CharField(max_length=300, verbose_name='User Fullname')
    origin = models.CharField(max_length=300, verbose_name='Origin')
    destination = models.CharField(max_length=300, verbose_name='Destination')
    date_time = models.DateTimeField(auto_now_add=True, verbose_name='Date Time')

    class Meta:
        verbose_name = 'Reservation'
        verbose_name_plural = 'Reservations'
        ordering = ['date_time']
        db_table = 'reservation_model'

    def __str__(self):
        return f"{self.origin} - {self.destination} - {self.date_time}"


class TelephoneTaxiModel(models.Model):
    organization = models.CharField(max_length=300, verbose_name='Organization')
    server_url = models.URLField(verbose_name='Server URL')
    description = models.TextField(null=True, blank=True, verbose_name='Description')
    is_active = models.BooleanField(default=True, verbose_name='Is Active')

    class Meta:
        verbose_name = 'Telephone Taxi'
        verbose_name_plural = 'Telephone Taxi'
        ordering = ['organization']
        db_table = 'telephone_taxi_model'

    def __str__(self):
        return f"{self.organization} - {self.server_url}"


class InscriptionModel(models.Model):
    private_key = models.TextField(verbose_name='private key')
    public_key  = models.TextField(verbose_name='public key')
    use_count = models.PositiveIntegerField(verbose_name='use count')

    class Meta:
        verbose_name = 'Inscription'
        verbose_name_plural = 'Inscriptions'
        ordering = ['id']
        db_table = 'inscription_model'

    def __str__(self):
        return f"{self.private_key} - {self.public_key}"


