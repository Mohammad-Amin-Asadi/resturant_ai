from django.apps import AppConfig


class ReservationModuleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Reservation_Module'
    verbose_name = 'Reservation Module'
