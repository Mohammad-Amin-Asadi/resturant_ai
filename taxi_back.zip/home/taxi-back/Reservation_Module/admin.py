from django.contrib import admin

from Reservation_Module.models import ReservationModel, TelephoneTaxiModel


@admin.register(ReservationModel)
class ReservationAdmin(admin.ModelAdmin):
    ...


@admin.register(TelephoneTaxiModel)
class TelephoneTaxiAdmin(admin.ModelAdmin):
    ...
