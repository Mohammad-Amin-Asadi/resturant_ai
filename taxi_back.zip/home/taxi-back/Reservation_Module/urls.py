from django.urls import path

from Reservation_Module.views import ReservationListView, SettingView, AddReservationView, DeleteReservationView

urlpatterns = [
    path('', ReservationListView.as_view(), name='reservation_list_url'),
    path('settings/', SettingView.as_view(), name='settings_url'),
    path('add-reservation/', AddReservationView.as_view(), name='add_reservation_url'),
    path('delete-reservation/<int:reservation_id>/', DeleteReservationView.as_view(), name='delete_reservation_url')
]
